#include <iostream>
using namespace std;
#include<string>
int main() {
    string name;
    cout << "Please input your name:" <<endl;
    cin >> name;
    cout << "hello" << name << "! Welcome to C++!"<< endl;
    return 0;
}
